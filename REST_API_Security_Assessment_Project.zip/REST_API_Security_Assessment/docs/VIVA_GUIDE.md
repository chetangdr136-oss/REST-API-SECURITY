# Invigilator Demonstration & Viva Guide

## 60-second project introduction
"Good morning. My project is REST API Security Assessment Tool. REST APIs connect applications and exchange data, so they must verify who is making a request and what that user is allowed to access. This project is written in Python. It checks selected security headers, CORS behavior, authentication enforcement on a sample endpoint, basic input handling, and rate-limit signals. It displays evidence and recommendations in a dashboard and exports a PDF report. I have also included a local demo API so the assessment can be demonstrated safely without targeting a public system."

## Live demonstration (about 5 minutes)
1. Open the project folder in VS Code.
2. Open Terminal 1 and run `python demo_api.py`.
3. Explain: "This starts a deliberately vulnerable training API on 127.0.0.1, which means it is accessible only from this computer."
4. Open Terminal 2 and run `streamlit run app.py`.
5. In the dashboard, keep the target as `http://127.0.0.1:5001`.
6. Click **Run assessment**.
7. Expand **Authentication enforcement**. Explain that `/api/profile` returned HTTP 200 without credentials, so the tool reports a potential missing-authentication issue.
8. Expand **Security headers**. Explain that response headers tell clients and browsers how to handle content and transport.
9. Explain the CORS observation: a server should allow only trusted browser origins when cross-origin access is needed.
10. Download the PDF and show the evidence and recommendations.

## Explain each check in simple language
- **Authentication:** "Authentication asks: Who are you? A private endpoint should not return protected information to an unauthenticated caller."
- **Authorization:** "Authorization asks: What are you allowed to do? This prototype does not fully prove role-based authorization; that requires separate test accounts and endpoint-specific rules."
- **Security headers:** "These are response instructions that reduce certain browser and transport risks. Which headers are appropriate depends on whether the API serves browser content and whether HTTPS is used."
- **CORS:** "CORS controls which browser origins may read responses. It is not a replacement for authentication."
- **Input validation:** "The tool sends a harmless unexpected query value and checks whether the API fails with a server error. A safe API should validate inputs and return controlled client errors."
- **Rate limiting:** "The tool sends a tiny number of requests and looks for HTTP 429, which means Too Many Requests. This is only an observation, not a load test."

## Common viva questions and answers

**Q1. What is a REST API?**  
A REST API is an interface that lets software systems communicate over HTTP using methods such as GET, POST, PUT, PATCH, and DELETE.

**Q2. What is the difference between authentication and authorization?**  
Authentication verifies identity. Authorization checks permissions after identity is known.

**Q3. What is HTTP 401?**  
401 means the request lacks valid authentication credentials.

**Q4. What is HTTP 403?**  
403 means the server understood the request but refuses to authorize it.

**Q5. What is CORS?**  
Cross-Origin Resource Sharing is a browser mechanism that controls whether a web page from one origin can read resources from another origin.

**Q6. What is rate limiting?**  
It restricts how many requests a client can make in a time window to reduce abuse and protect availability.

**Q7. What is input validation?**  
It checks that incoming values have the expected type, length, and format before processing.

**Q8. Why Python?**  
Python has readable syntax and useful libraries such as Requests and Flask, making it suitable for rapid security-tool development.

**Q9. What does the scanner do when it finds a missing header?**  
It records the check name, severity, observed evidence, and a recommendation. It does not claim that the entire API is vulnerable based on one missing header.

**Q10. Does this tool guarantee that an API is secure?**  
No. It performs a limited set of baseline checks. A full assessment needs endpoint discovery, role-based authorization tests, code review, and manual verification.

**Q11. What is the purpose of the demo API?**  
It gives a safe and repeatable target with a known weakness so the examiner can see the scanner detect it.

**Q12. What is the main limitation?**  
It uses a few conventional endpoint paths and low-impact probes. Real APIs need endpoint-specific test cases and authorized test accounts.

## If the examiner asks "What is the main output?"
"The main output is a list of findings. Each finding contains the check name, severity, status, evidence from the response, and a recommendation. The same information can be downloaded as a PDF or JSON file."

## Important honesty point
Do not claim that this prototype fully detects SQL injection, broken object-level authorization (BOLA), or every OWASP API Top 10 issue. Explain that these are important extensions requiring endpoint-specific test data and controlled test accounts.
