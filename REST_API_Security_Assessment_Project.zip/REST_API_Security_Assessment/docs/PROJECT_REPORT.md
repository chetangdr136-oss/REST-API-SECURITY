# Project Report: REST API Security Assessment Tool

## Abstract
REST APIs are widely used to exchange data between web, mobile, and cloud applications. Incorrect authentication, permissive CORS settings, missing security headers, weak input validation, and absent rate limiting can expose data or services to abuse. This project implements a Python-based educational assessment tool that performs a small set of low-impact checks against an explicitly authorized REST API and presents findings with evidence and remediation guidance.

## 1. Introduction
The project aims to make basic REST API security checks easier to understand and demonstrate. It combines a Streamlit dashboard, a Python assessment engine, a PDF report generator, and a local intentionally vulnerable Flask API.

## 2. Problem statement
Manual inspection of API responses can be time-consuming for beginners. A student needs a repeatable way to inspect common API security controls, understand the evidence, and document suggested improvements.

## 3. Objectives
1. Accept a REST API base URL.
2. inspect selected HTTP response security headers.
3. Review CORS response behavior.
4. Compare an unauthenticated request against an optional authorized Bearer-token request.
5. Send a harmless unexpected input and observe error handling.
6. Make a small rate-limit observation without generating heavy traffic.
7. Display findings and export PDF/JSON reports.
8. Provide a safe local API for demonstration.

## 4. Technology stack
- Python 3.10+
- Requests: HTTP communication
- Flask: local demonstration API
- Streamlit: user interface
- ReportLab: PDF generation

## 5. System modules
### 5.1 User interface (`app.py`)
Collects the target URL and optional test token, starts the assessment, displays findings, and provides report downloads.

### 5.2 Assessment engine (`scanner.py`)
Runs the checks and converts observations into structured findings with severity, evidence, and recommendations.

### 5.3 Demo API (`demo_api.py`)
Provides a local training target. `/api/profile` intentionally returns profile-like data without authentication to demonstrate a missing authentication control. The service binds to 127.0.0.1 only.

### 5.4 Report generator (`report.py`)
Creates a PDF containing target details and a table of findings.

## 6. Methodology
1. Normalize and validate the supplied base URL.
2. Request the API root to confirm connectivity.
3. Inspect selected response headers.
4. Send a benign Origin header to observe CORS behavior.
5. Request `/api/profile` without credentials and inspect the status code.
6. If a test Bearer token is supplied, repeat the request with that token.
7. Send a harmless unexpected query value to `/api/search`.
8. Make a small number of `/health` requests and look for HTTP 429.
9. Store evidence and recommendations in JSON and render a PDF report.

## 7. Expected demonstration
When run against the included demo API, the tool should identify that `/api/profile` responds with HTTP 200 without an Authorization header. It may also flag missing security headers and report the CORS and rate-limit observations. The exact findings depend on the API response.

## 8. Security and ethical considerations
Only test systems that you own or have explicit permission to assess. The included demo server listens on loopback. The rate-limit check is intentionally small. The tool does not guess passwords, exploit SQL injection, modify data, or perform denial-of-service testing.

## 9. Limitations
- The tool checks conventional paths and cannot discover every endpoint.
- A status code is an indicator, not proof of a vulnerability.
- Authorization depends on roles, ownership, and business rules and requires manual test cases.
- Header requirements depend on deployment context; for example, HSTS applies to HTTPS.
- The small rate-limit observation cannot prove that rate limiting is absent.
- It is not a replacement for OWASP API Security Top 10 testing or a professional penetration test.

## 10. Future scope
- Import OpenAPI/Swagger specifications.
- Add endpoint discovery from an authorized specification.
- Add role-based authorization test cases with two test accounts.
- Add authenticated test profiles and configurable endpoint paths.
- Export HTML and CSV reports.
- Add integration with CI pipelines.

## 11. Conclusion
The project demonstrates a practical baseline workflow for REST API security assessment. It automates selected checks, explains evidence, and produces a report that can help developers prioritize manual verification and remediation.
